NECTAR RANK PREFIXES - MINECRAFT JAVA 1.21.11

This pack uses the four original PNG prefix designs supplied for the project.

CUSTOM FONT
nectar:ranks

GLYPHS
BUILDER = U+E001 = 
ADMIN   = U+E002 = 
OWNER   = U+E003 = 
NECTAR  = U+E004 = 

TEST COMMANDS
After enabling this resource pack, run these in Minecraft Java chat:

a) /tellraw @s {"text":"","font":"nectar:ranks"}
b) /tellraw @s {"text":"","font":"nectar:ranks"}
c) /tellraw @s {"text":"","font":"nectar:ranks"}
d) /tellraw @s {"text":"","font":"nectar:ranks"}

The resource pack only provides the graphics/font. It does not automatically
change chat prefixes. The server's chat/rank system must output the glyph and
use the nectar:ranks font for the prefix component.

PLAYER is not included because no PLAYER PNG was supplied in the project files.
